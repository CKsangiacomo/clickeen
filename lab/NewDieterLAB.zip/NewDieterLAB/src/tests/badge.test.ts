import { describe, it, expect } from 'vitest';
import { JSDOM } from 'jsdom';

import badgeGridHtml from '../html/components/badge-grid.html?raw';
import badgeStateInteractiveHtml from '../html/components/badge-state-interactive.html?raw';
import badgeStateDismissHtml from '../html/components/badge-state-dismiss.html?raw';
import badgeStateOutlineHtml from '../html/components/badge-state-outline.html?raw';
import badgeStateIconHtml from '../html/components/badge-state-icon.html?raw';

const parse = (markup: string) =>
  new JSDOM(`<div id="root">${markup}</div>`).window.document.querySelector('#root')!;

describe('Badge demos', () => {
  it('renders every type across the size presets', () => {
    const fragment = parse(badgeGridHtml);
    const types = ['info', 'success', 'warning', 'error', 'neutral', 'recommendation'] as const;

    types.forEach((type) => {
      const badges = Array.from(
        fragment.querySelectorAll<HTMLSpanElement>(`.diet-badge[data-type="${type}"]`)
      );
      expect(badges.length).toBeGreaterThan(0);
      const sizes = new Set(badges.map((badge) => badge.getAttribute('data-size')));
      expect(sizes.has('sm')).toBe(true);
      expect(sizes.has('md')).toBe(true);
      expect(sizes.has('lg')).toBe(true);
    });
  });

  it('includes tone examples for subtle, outline, and washes', () => {
    const fragment = parse(badgeGridHtml);
    expect(fragment.querySelector('.diet-badge[data-tone="subtle"]')).not.toBeNull();
    expect(fragment.querySelector('.diet-badge[data-tone="outline"]')).not.toBeNull();
    expect(fragment.querySelector('.diet-badge[data-tone="wash-light"]')).not.toBeNull();
    expect(fragment.querySelector('.diet-badge[data-tone="wash-dark"]')).not.toBeNull();
  });

  it('marks interactive outline badges with tabindex', () => {
    const fragment = parse(badgeStateInteractiveHtml);
    const interactive = fragment.querySelector<HTMLSpanElement>('.diet-badge[data-interactive="true"]');
    expect(interactive).not.toBeNull();
    expect(interactive?.getAttribute('tabindex')).toBe('0');
  });

  it('provides dismiss button with aria-label', () => {
    const fragment = parse(badgeStateDismissHtml);
    const dismiss = fragment.querySelector<HTMLButtonElement>('.diet-badge__dismiss');
    expect(dismiss).not.toBeNull();
    expect(dismiss?.getAttribute('aria-label')).toBeTruthy();
  });

  it('renders icon slot with aria-hidden glyph', () => {
    const fragment = parse(badgeStateIconHtml);
    const icon = fragment.querySelector('.diet-badge__icon');
    expect(icon).not.toBeNull();
    expect(icon?.getAttribute('aria-hidden')).toBe('true');
  });

  it('renders outline tone demo snippet', () => {
    const fragment = parse(badgeStateOutlineHtml);
    const outline = fragment.querySelector<HTMLSpanElement>('.diet-badge[data-tone="outline"]');
    expect(outline).not.toBeNull();
  });
});

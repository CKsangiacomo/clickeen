import { describe, it, expect } from 'vitest';
import { JSDOM } from 'jsdom';

import gridHtml from '../html/components/container-grid.html?raw';
import fullHtml from '../html/components/container-state-full.html?raw';
import centerHtml from '../html/components/container-state-center.html?raw';
import nopadHtml from '../html/components/container-state-nopad.html?raw';

const parse = (markup: string) =>
  new JSDOM(`<div id="root">${markup}</div>`).window.document.querySelector('#root')!;

describe('Container demos', () => {
  it('renders clamp variants for sm, md, lg, and xl', () => {
    const fragment = parse(gridHtml);
    const containers = Array.from(fragment.querySelectorAll('.diet-container'));
    expect(containers.length).toBeGreaterThanOrEqual(4);

    const widths = new Set(containers.map((el) => el.getAttribute('data-width')));
    expect(widths.has('sm')).toBe(true);
    expect(widths.has('md')).toBe(true);
    expect(widths.has('lg')).toBe(true);
    expect(widths.has('xl')).toBe(true);
  });

  it('demonstrates full bleed mode', () => {
    const fragment = parse(fullHtml);
    const full = fragment.querySelector('.diet-container[data-width="full"]');
    expect(full).not.toBeNull();
    expect(full?.getAttribute('data-padding')).toBe('lg');
  });

  it('shows centered alignment with actions', () => {
    const fragment = parse(centerHtml);
    const centered = fragment.querySelector('.diet-container[data-align="center"]');
    expect(centered).not.toBeNull();
    const cta = centered?.querySelector('.diet-btn');
    expect(cta).not.toBeNull();
  });

  it('illustrates padding removal', () => {
    const fragment = parse(nopadHtml);
    const none = fragment.querySelector('.diet-container[data-padding="none"]');
    expect(none).not.toBeNull();
  });
});

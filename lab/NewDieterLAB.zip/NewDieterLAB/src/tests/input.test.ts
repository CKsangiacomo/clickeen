import { describe, it, expect } from 'vitest';
import { JSDOM } from 'jsdom';

import gridHtml from '../html/components/input-grid.html?raw';
import errorHtml from '../html/components/input-state-error.html?raw';
import disabledHtml from '../html/components/input-state-disabled.html?raw';
import snippetHtml from '../html/components/input-snippet.html?raw';

const parse = (markup: string) =>
  new JSDOM(`<div id="root">${markup}</div>`).window.document.querySelector('#root')!;

describe('Input demos', () => {
  it('renders size presets', () => {
    const fragment = parse(gridHtml);
    const wrappers = fragment.querySelectorAll('.diet-input');
    expect(wrappers.length).toBeGreaterThanOrEqual(3);
    const sizes = new Set(Array.from(wrappers).map((node) => node.getAttribute('data-size')));
    expect(sizes.has('sm')).toBe(true);
    expect(sizes.has('md') || sizes.has(null)).toBe(true);
    expect(sizes.has('lg')).toBe(true);
  });

  it('connects error helper via aria-describedby', () => {
    const fragment = parse(errorHtml);
    const helper = fragment.querySelector('.diet-input__helper');
    const field = fragment.querySelector<HTMLInputElement>('.diet-input__field');
    expect(helper?.id).toBeTruthy();
    expect(field?.getAttribute('aria-describedby')).toBe(helper?.id ?? null);
  });

  it('shows disabled state styling', () => {
    const fragment = parse(disabledHtml);
    const disabled = fragment.querySelector('.diet-input[data-state="disabled"]');
    const field = disabled?.querySelector<HTMLInputElement>('.diet-input__field');
    expect(disabled).not.toBeNull();
    expect(field?.disabled).toBe(true);
  });

  it('includes snippet usage with multiple inputs', () => {
    const fragment = parse(snippetHtml);
    const inputs = fragment.querySelectorAll('.diet-input');
    expect(inputs.length).toBeGreaterThanOrEqual(2);
  });
});

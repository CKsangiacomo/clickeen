import '@dieter/dist/tokens.css';
import '@dieter/dist/components/button.css';
import '@dieter/dist/components/segmented.css';
import './css/components/primitives/badge.css';
import './css/components/primitives/box.css';
import './css/components/primitives/container.css';
import './css/components/primitives/divider.css';

import { dieterPreviews } from './data/dieter';
import {
  componentDocs,
  componentIndex,
  navGroups,
  type ComponentDocSpec,
  type NavItem,
} from './data/routes';
import { navigate, startRouter, type RouteMatch } from './router';

const htmlFragments = import.meta.glob('../html/**/*.html', {
  query: '?raw',
  import: 'default',
  eager: true,
});

const getFragment = (path: string): string => {
  const normalised = path.startsWith('../') ? path : `../${path}`;
  const fragment =
    htmlFragments[normalised] ??
    htmlFragments[`${normalised}?raw` as keyof typeof htmlFragments];
  return typeof fragment === 'string' ? fragment : '<!-- MISSING FRAGMENT -->';
};

const app = document.getElementById('app');
if (!app) throw new Error('Root app container not found');

const shell = document.createElement('div');
shell.className = 'docs-shell';

const sidebar = document.createElement('aside');
sidebar.className = 'docs-shell__sidebar';
sidebar.setAttribute('aria-label', 'Site navigation');

const overlay = document.createElement('div');
overlay.className = 'docs-shell__overlay';
overlay.setAttribute('aria-hidden', 'true');


const main = document.createElement('main');
main.className = 'docs-shell__main';

const contentSection = document.createElement('section');
contentSection.className = 'docs-shell__content';
main.append(contentSection);

shell.append(sidebar, overlay, main);
app.append(shell);

const toggleButton = document.createElement('button');
toggleButton.type = 'button';
toggleButton.className = 'docs-shell__menu-toggle nav-link';
toggleButton.setAttribute('aria-expanded', 'false');
toggleButton.textContent = '☰';

toggleButton.addEventListener('click', () => {
  const isOpen = sidebar.getAttribute('data-state') === 'open';
  sidebar.setAttribute('data-state', isOpen ? 'closed' : 'open');
  overlay.setAttribute('data-state', isOpen ? 'closed' : 'open');
  toggleButton.setAttribute('aria-expanded', String(!isOpen));
});

overlay.addEventListener('click', () => {
  sidebar.setAttribute('data-state', 'closed');
  overlay.setAttribute('data-state', 'closed');
  toggleButton.setAttribute('aria-expanded', 'false');
});


const brandSection = document.createElement('div');
brandSection.className = 'docs-shell__brand';

const brandTitle = document.createElement('h1');
brandTitle.className = 'heading-2';
brandTitle.style.margin = '0';
brandTitle.textContent = 'Dieter';

const themeControl = document.createElement('div');
themeControl.className = 'diet-segmented';
themeControl.setAttribute('role', 'radiogroup');
themeControl.setAttribute('data-size', 'lg');
themeControl.setAttribute('data-footprint', 'icon-only');
themeControl.innerHTML = `
  <label class="diet-segment">
    <input type="radio" name="theme" value="light" class="diet-segment__input" checked>
    <span class="diet-segment__surface"></span>
    <span class="diet-segment__icon">
      <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><circle cx="8" cy="8" r="3.5" fill="currentColor"/><path d="M8 1v2M8 13v2M15 8h-2M3 8H1M12.95 3.05l-1.41 1.41M4.46 11.54l-1.41 1.41M12.95 12.95l-1.41-1.41M4.46 4.46L3.05 3.05" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>
    </span>
    <span class="diet-segment__sr">Light theme</span>
  </label>
  <label class="diet-segment">
    <input type="radio" name="theme" value="dark" class="diet-segment__input">
    <span class="diet-segment__surface"></span>
    <span class="diet-segment__icon">
      <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M14 8.5c-.3 3.9-3.6 7-7.5 7C2.9 15.5 0 12.6 0 9S2.9 2.5 6.5 2.5c.8 0 1.5.1 2.2.4-.5.6-.7 1.4-.7 2.2 0 2.1 1.7 3.8 3.8 3.8.8 0 1.6-.2 2.2-.6z" fill="currentColor"/></svg>
    </span>
    <span class="diet-segment__sr">Dark theme</span>
  </label>
`;

themeControl.querySelectorAll('input[name="theme"]').forEach((input) => {
  input.addEventListener('change', (e) => {
    const target = e.target as HTMLInputElement;
    if (target.checked) {
      document.documentElement.setAttribute('data-theme', target.value);
    }
  });
});

brandSection.append(brandTitle, themeControl);

const navContainer = document.createElement('nav');
navContainer.className = 'docs-shell__nav';

const createNavGroup = (groupTitle: string, items: NavItem[]) => {
  const group = document.createElement('div');
  group.className = 'nav-group';

  if (groupTitle) {
    const title = document.createElement('p');
    title.className = 'nav-group__title';
    title.textContent = groupTitle;
    group.append(title);
  }

  const list = document.createElement('ul');
  list.className = 'nav-group__list';

  items.forEach((item) => {
    const li = document.createElement('li');
    const link = document.createElement('a');
    link.className = 'nav-link';
    link.href = item.path;
    link.textContent = item.title;
    link.addEventListener('click', (event) => {
      event.preventDefault();
      navigate(item.path);
    });
    li.append(link);
    list.append(li);
  });

  group.append(list);
  return group;
};

navGroups.forEach((group, index) => {
  navContainer.append(createNavGroup(group.title, group.items));
  if (group.id === 'dieter') {
    const divider = document.createElement('div');
    divider.className = 'nav-divider';
    navContainer.append(divider);
  }
});

sidebar.append(brandSection, navContainer);

type RenderResult = HTMLElement;

const renderHome = () => {
  const article = document.createElement('article');
  article.className = 'stack';

  const overview = document.createElement('header');
  overview.className = 'stack';
  overview.innerHTML = `
    <p class="overline">Welcome</p>
    <h1 class="heading-2" style="margin:0">Dieter Component Lab</h1>
    <p class="body" style="margin:0">CSS-first sandbox for future Dieter contracts.</p>
  `;

  const list = document.createElement('div');
  list.className = 'grid-auto';
  componentDocs.forEach((spec) => {
    list.append(createCard(spec.title, spec.summary, `#/components/${spec.id}`, spec.status));
  });

  article.append(overview, list);
  return article;
};
const renderShowcase = (slug?: string): RenderResult => {
  if (!slug) return renderNotFound('Component showcase not specified');
  const preview = dieterPreviews.find((item) => item.slug === slug);
  if (!preview) return renderNotFound('Component showcase not found');

  const article = document.createElement('article');
  article.className = 'stack';

  const headerSection = document.createElement('header');
  headerSection.className = 'stack';
  headerSection.innerHTML = `
    <h1 class="heading-2" style="margin:0">${preview.title}</h1>
  `;

  const previewSection = document.createElement('section');
  previewSection.id = 'preview';
  previewSection.className = 'stack';
  previewSection.append(buildHtmlFragment(preview.htmlPath));

  const cssSection = createSection('css-contract', 'CSS contract', buildCodeBlock(preview.css.map((href) => `import '${href}';`).join('\n')));

  article.append(headerSection, previewSection, cssSection);
  return article;
};

const renderComponent = (slug?: string): RenderResult => {
  if (!slug) return renderNotFound('Component not specified');
  const spec = componentIndex.get(slug);
  if (!spec) return renderNotFound('Component not found');

  const article = document.createElement('article');
  article.className = 'stack';

  const overviewSection = document.createElement('header');
  overviewSection.className = 'stack';
  const heading = document.createElement('h1');
  heading.className = 'heading-2';
  heading.style.margin = '0';
  heading.textContent = spec.title;
  overviewSection.append(heading);

  if (spec.summary) {
    const summary = document.createElement('p');
    summary.className = 'body';
    summary.style.margin = '0';
    summary.textContent = spec.summary;
    overviewSection.append(summary);
  }

  const sections: HTMLElement[] = [overviewSection];

  const gridSection = createSection('variants-grid', spec.grid.heading, buildGrid(spec));
  sections.push(gridSection);

  if (spec.states.length > 0) {
    sections.push(createSection('states', 'States', buildStates(spec)));
  }

  sections.push(createDetailsSection(spec));

  article.append(...sections);
  return article;
};

const renderNotFound = (message: string): RenderResult => {
  const article = document.createElement('article');
  article.className = 'stack';
  const heading = document.createElement('h1');
  heading.className = 'heading-3';
  heading.textContent = 'Not found';
  const paragraph = document.createElement('p');
  paragraph.textContent = message;
  article.append(heading, paragraph);
  return article;
};

function createSectionHeading(text: string) {
  const heading = document.createElement('h2');
  heading.className = 'heading-4';
  heading.style.margin = '0';
  heading.textContent = text;
  return heading;
}

function createBodyText(text: string) {
  const paragraph = document.createElement('p');
  paragraph.className = 'body';
  paragraph.style.margin = '0';
  paragraph.textContent = text;
  return paragraph;
}

const createCard = (title: string, description: string, href: string, label = 'Planned') => {
  const card = document.createElement('a');
  card.className = 'home-card';
  card.href = href;
  card.addEventListener('click', (event) => {
    event.preventDefault();
    navigate(href);
  });

  const overline = document.createElement('span');
  overline.className = 'overline';
  overline.textContent = label;

  const heading = document.createElement('strong');
  heading.className = 'heading-5';
  heading.style.margin = '0';
  heading.textContent = title;

  const paragraph = document.createElement('p');
  paragraph.className = 'body';
  paragraph.style.margin = '0';
  paragraph.textContent = description;

  card.append(overline, heading, paragraph);
  return card;
};

const buildHtmlFragment = (path: string) => {
  const wrapper = document.createElement('div');
  wrapper.className = 'demo-fragment';
  wrapper.innerHTML = getFragment(path);
  return wrapper;
};

const buildCodeBlock = (code: string) => {
  const pre = document.createElement('pre');
  const codeEl = document.createElement('code');
  codeEl.textContent = code;
  pre.append(codeEl);
  return pre;
};

const createSection = (id: string, title: string, body: HTMLElement | HTMLElement[]): HTMLElement => {
  const section = document.createElement('section');
  section.className = 'stack';
  section.id = id;

  const heading = document.createElement('h2');
  heading.className = 'heading-4';
  heading.style.margin = '0';
  heading.textContent = title;
  section.append(heading);

  const divider = document.createElement('div');
  divider.className = 'nav-divider';
  section.append(divider);

  if (Array.isArray(body)) {
    body.forEach((element) => section.append(element));
  } else {
    section.append(body);
  }

  return section;
};

const buildGrid = (spec: ComponentDocSpec) => {
  const container = document.createElement('div');
  container.className = 'component-grid';

  spec.grid.variants.forEach((variant) => {
    const row = document.createElement('div');
    row.className = 'component-grid__row';

    const meta = document.createElement('div');
    meta.className = 'component-grid__meta';
    if (variant.name) {
      const heading = document.createElement('strong');
      heading.textContent = variant.name;
      meta.append(heading);
    }
    if (variant.description) {
      const desc = document.createElement('p');
      desc.textContent = variant.description;
      meta.append(desc);
    }
    if (spec.grid.sizes.length > 0) {
      const sizeNote = document.createElement('p');
      sizeNote.textContent = `Sizes: ${spec.grid.sizes.join(', ')}`;
      meta.append(sizeNote);
    }

    const demos = document.createElement('div');
    demos.className = 'component-grid__demos';
    demos.innerHTML = getFragment(variant.demoPath);

    row.append(meta, demos);
    container.append(row);
  });

  return container;
};

const buildStates = (spec: ComponentDocSpec) => {
  const strip = document.createElement('div');
  strip.className = 'state-strip';
  spec.states.forEach((state) => {
    const tile = document.createElement('div');
    tile.className = 'state-strip__tile';
    const label = document.createElement('strong');
    label.textContent = state.name;
    tile.append(label);
    const body = document.createElement('div');
    body.innerHTML = getFragment(state.demoPath);
    tile.append(body);
    if (state.notes) {
      const notes = document.createElement('p');
      notes.textContent = state.notes;
      tile.append(notes);
    }
    strip.append(tile);
  });
  return strip;
};

const buildDetailsSection = (label: string, content: HTMLElement) => {
  const details = document.createElement('details');
  const summary = document.createElement('summary');
  summary.textContent = label;
  details.append(summary, content);
  return details;
};

const createDetailsSection = (spec: ComponentDocSpec) => {
  const wrapper = document.createElement('section');
  wrapper.className = 'stack';
  wrapper.id = 'details';

  const heading = document.createElement('h2');
  heading.className = 'heading-4';
  heading.style.margin = '0';
  heading.textContent = 'Documentation';
  wrapper.append(heading);

  const anatomy = document.createElement('ul');
  anatomy.className = 'stack';
  spec.anatomy.forEach((item) => {
    const li = document.createElement('li');
    li.textContent = item;
    anatomy.append(li);
  });

  const anatomyDetails = buildDetailsSection('Anatomy', anatomy);

  const cssList = document.createElement('ul');
  if (spec.css.length === 0) {
    const li = document.createElement('li');
    li.textContent = 'MISSING: CSS contract will be linked with implementation.';
    cssList.append(li);
  } else {
    spec.css.forEach((path) => {
      const li = document.createElement('li');
      li.textContent = path;
      cssList.append(li);
    });
  }
  const cssDetails = buildDetailsSection('CSS files', cssList);

  const tokensList = document.createElement('ul');
  if (spec.ai.tokens.length === 0) {
    const li = document.createElement('li');
    li.textContent = 'MISSING: tokens will be documented with implementation.';
    tokensList.append(li);
  } else {
    spec.ai.tokens.forEach((token) => {
      const li = document.createElement('li');
      li.textContent = token;
      tokensList.append(li);
    });
  }
  const tokensDetails = buildDetailsSection('Tokens', tokensList);

  const ariaList = document.createElement('ul');
  if (spec.ai.aria.role) {
    const li = document.createElement('li');
    li.textContent = `role="${spec.ai.aria.role}"`;
    ariaList.append(li);
  }
  (spec.ai.aria.attributes ?? []).forEach((attribute) => {
    const li = document.createElement('li');
    li.textContent = attribute;
    ariaList.append(li);
  });
  if (ariaList.children.length === 0) {
    const li = document.createElement('li');
    li.textContent = 'MISSING: accessibility guidance will be added with implementation.';
    ariaList.append(li);
  }
  const ariaDetails = buildDetailsSection('Accessibility', ariaList);

  const aiWrapper = document.createElement('div');
  aiWrapper.className = 'stack';

  const appendList = (label: string, items: string[], fallback: string) => {
    const block = document.createElement('div');
    block.className = 'stack-sm';
    const subheading = document.createElement('span');
    subheading.className = 'overline';
    subheading.textContent = label;
    block.append(subheading);

    const list = document.createElement('ul');
    if (items.length === 0) {
      const li = document.createElement('li');
      li.textContent = fallback;
      list.append(li);
    } else {
      items.forEach((item) => {
        const li = document.createElement('li');
        li.textContent = item;
        list.append(li);
      });
    }

    block.append(list);
    aiWrapper.append(block);
  };

  appendList('Class names', spec.ai.classNames, 'MISSING: class names pending implementation.');
  appendList('Markup', spec.ai.markup, 'MISSING: markup contract will be added with implementation.');
  appendList('States & data attributes', spec.ai.states, 'MISSING: state matrix not documented yet.');
  appendList('Selectors', spec.ai.selectors, 'MISSING: selectors to be documented.');
  appendList('Do nots', spec.ai.doNots, 'MISSING: anti-patterns to be listed.');

  const aiDetails = buildDetailsSection('AI contract', aiWrapper);

  const examplesWrapper = document.createElement('div');
  examplesWrapper.className = 'stack';
  if (spec.examples.length === 0) {
    const placeholder = document.createElement('p');
    placeholder.textContent = 'MISSING: snippets will accompany the implementation.';
    examplesWrapper.append(placeholder);
  } else {
    spec.examples.forEach((example) => {
      const details = document.createElement('details');
      const summary = document.createElement('summary');
      summary.textContent = example.title;
      const body = document.createElement('div');
      body.innerHTML = getFragment(example.htmlPath);
      details.append(summary, body);
      examplesWrapper.append(details);
    });
  }
  const examplesDetails = buildDetailsSection('Snippets', examplesWrapper);

  wrapper.append(anatomyDetails, cssDetails, tokensDetails, ariaDetails, aiDetails, examplesDetails);
  return wrapper;
};

const setActiveNav = (path: string) => {
  const links = sidebar.querySelectorAll<HTMLAnchorElement>('a.nav-link');
  links.forEach((link) => {
    if (link.getAttribute('href') === path) {
      link.setAttribute('aria-current', 'page');
    } else {
      link.removeAttribute('aria-current');
    }
  });
};

const handleRoute = (match: RouteMatch) => {
  let rendered: RenderResult;
  if (match.kind === 'home') {
    rendered = renderHome();
    document.title = 'New Dieter Lab · Home';
    setActiveNav('#/');
  } else if (match.kind === 'showcase') {
    rendered = renderShowcase(match.slug);
    document.title = `New Dieter Lab · Dieter · ${match.slug ?? ''}`;
    setActiveNav(`#/dieter/${match.slug ?? ''}`);
  } else {
    rendered = renderComponent(match.slug);
    document.title = `New Dieter Lab · Component · ${match.slug ?? ''}`;
    setActiveNav(`#/components/${match.slug ?? ''}`);
  }

  contentSection.replaceChildren(rendered);
};

startRouter(handleRoute);

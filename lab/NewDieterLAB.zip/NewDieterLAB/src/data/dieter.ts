export interface DieterPreview {
  id: string;
  title: string;
  slug: string;
  description: string;
  css: string[];
  htmlPath: string;
}

export const dieterPreviews: DieterPreview[] = [
  {
    id: 'dieter-button',
    title: 'Button',
    slug: 'button',
    description: 'Current Dieter button contract as implemented in the published package.',
    css: ['@dieter/dist/components/button.css'],
    htmlPath: '../html/dieter/button.html',
  },
  {
    id: 'dieter-segmented',
    title: 'Segmented Control',
    slug: 'segmented',
    description: 'Segmented control contract mirrored from the Dieter distribution.',
    css: ['@dieter/dist/components/segmented.css'],
    htmlPath: '../html/dieter/segmented.html',
  },
  {
    id: 'dieter-colors',
    title: 'Color Tokens',
    slug: 'colors',
    description: 'Reference palette showing Dieter surface and role tokens.',
    css: ['@dieter/dist/tokens.css'],
    htmlPath: '../html/dieter/colors.html',
  },
  {
    id: 'dieter-typography',
    title: 'Typography Scale',
    slug: 'typography',
    description: 'Typography ladder pulled from the Dieter package for comparison.',
    css: ['@dieter/dist/tokens.css'],
    htmlPath: '../html/dieter/typography.html',
  },
];

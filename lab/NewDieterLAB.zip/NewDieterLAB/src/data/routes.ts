import { dieterPreviews } from './dieter';

export type NavItemKind = 'home' | 'showcase' | 'component';

export interface NavItem {
  id: string;
  title: string;
  path: string;
  kind: NavItemKind;
  summary?: string;
}

export interface NavGroup {
  id: string;
  title: string;
  items: NavItem[];
}

export type ComponentArea = 'primitive' | 'form' | 'overlay' | 'pattern' | 'extra';
export type ComponentStatus = 'Planned' | 'Core' | 'Pattern';

export type Key =
  | 'Enter'
  | 'Space'
  | 'Escape'
  | 'ArrowUp'
  | 'ArrowDown'
  | 'ArrowLeft'
  | 'ArrowRight';

export interface CSSContract {
  classNames: string[];
  markup: string[];
  states: string[];
  tokens: string[];
  aria: { role?: string; attributes?: string[]; keyboard?: Key[]; focus?: string };
  selectors: string[];
  doNots: string[];
}

export interface ComponentDocSpec {
  id: string;
  title: string;
  area: ComponentArea;
  status: ComponentStatus;
  summary: string;
  anatomy: string[];
  css: string[];
  grid: {
    heading: string;
    sizes: string[];
    variants: Array<{ name: string; description?: string; demoPath: string }>;
  };
  gridMatrixPath?: string;
  states: Array<{ name: string; demoPath: string; notes?: string }>;
  examples: Array<{ title: string; htmlPath: string }>;
  ai: CSSContract;
}

const componentAreas: Record<ComponentArea, { title: string; status: ComponentStatus }> = {
  primitive: { title: 'Primitives', status: 'Core' },
  form: { title: 'Forms', status: 'Core' },
  overlay: { title: 'Overlays & Menus', status: 'Core' },
  pattern: { title: 'Patterns', status: 'Pattern' },
  extra: { title: 'Extras', status: 'Planned' },
};

const baseGrid = (path: string) => ({
  heading: 'Variants × Sizes',
  sizes: ['sm', 'md', 'lg'],
  variants: [
    { name: 'Default', description: 'TODO', demoPath: path },
  ],
});

const baseStates = (path: string) => [{ name: 'Default state', demoPath: path }];

const baseAI = (): CSSContract => ({
  classNames: [],
  markup: [],
  states: [],
  tokens: [],
  aria: {},
  selectors: [],
  doNots: ['MISSING: document once implementation exists.'],
});

const folderForArea = (area: ComponentArea) =>
  area === 'primitive'
    ? 'primitives'
    : area === 'form'
    ? 'forms'
    : area === 'overlay'
    ? 'overlays'
    : area === 'pattern'
    ? 'patterns'
    : 'extras';

const createSpec = (id: string, title: string, area: ComponentArea, summary: string): ComponentDocSpec => {
  const htmlPath = `../html/components/${id}.html?raw`;
  return {
    id,
    title,
    area,
    status: componentAreas[area].status,
    summary,
    anatomy: ['MISSING: anatomy pending implementation.'],
    css: [],
    grid: baseGrid(htmlPath),
    states: baseStates(htmlPath),
    examples: [],
    ai: baseAI(),
  };
};

const dieterItems: NavItem[] = dieterPreviews.map((preview) => ({
  id: preview.id,
  title: preview.title,
  path: `#/dieter/${preview.slug}`,
  kind: 'showcase' as const,
  summary: preview.description,
}));

export const componentDocs: ComponentDocSpec[] = [
  createSpec('badge', 'Badge', 'primitive', 'Status pill for compact metadata.'),
  createSpec('box', 'Box', 'primitive', 'Layout primitive exposing padding, background, and elevation tokens.'),
  createSpec('container', 'Container', 'primitive', 'Responsive page wrapper with width clamps and gutters.'),
  createSpec('divider', 'Divider', 'primitive', 'Horizontal or vertical separator aligning to Dieter spacing.'),
  createSpec('link', 'Link', 'primitive', 'Inline hyperlink styling with focus & visited states.'),
  createSpec('spinner', 'Spinner', 'primitive', 'Non-blocking progress indicator tokenized against Dieter motion rules.'),
  createSpec('input', 'Input', 'form', 'TextField control covering helper text, errors, and sizes.'),
  createSpec('textarea', 'Textarea', 'form', 'Multiline text input with resize policy and character count support.'),
  createSpec('checkbox', 'Checkbox', 'form', 'Binary selection control with indeterminate treatment.'),
  createSpec('radiogroup', 'Radio Group', 'form', 'Roving tabindex radio group with arrow key navigation.'),
  createSpec('select', 'Select', 'form', 'Single-select dropdown with Dieter trigger + native list fallback.'),
  createSpec('switch', 'Switch', 'form', 'Toggle control mirroring iOS look while honoring Dieter spacing.'),
  createSpec('fieldset', 'Fieldset', 'form', 'Legend + grouped input scaffolding for related controls.'),
  createSpec('modal', 'Modal', 'overlay', 'Modal dialog with focus trap, labelled headings, and Escape dismissal.'),
  createSpec('overlay-panel', 'Overlay Panel', 'overlay', 'Drawer/sheet sliding from edges with trap + aria-modal contract.'),
  createSpec('popover', 'Popover', 'overlay', 'Contextual bubble anchored to triggers with arrow placement helpers.'),
  createSpec('tooltip', 'Tooltip', 'overlay', 'Accessible tooltip with hover, focus, and keyboard dismissal.'),
  createSpec('tabs', 'Tabs', 'overlay', 'Tablist + tabpanel pattern supporting manual activation + keyboard nav.'),
  createSpec('toast', 'Toast', 'overlay', 'Transient notification region with polite live announcements.'),
  createSpec('dropdown', 'Dropdown', 'overlay', 'Menu-style surface for action lists, leveraging roving focus.'),
  createSpec('activation-card', 'Activation Card', 'pattern', 'Onboarding card that stacks primitives for actions and copy.'),
  createSpec('banner', 'Banner', 'pattern', 'Callout banner supporting upsell, success, and warning variants.'),
  createSpec('help-button', 'Help Button', 'pattern', 'Icon button + tooltip composition for inline help affordances.'),
  createSpec('page-header', 'Page Header', 'pattern', 'Structured page title with metadata, breadcrumbs, and actions.'),
  createSpec('mask', 'Mask', 'pattern', 'CSS mask utilities for cropping imagery to Dieter-friendly shapes.'),
  createSpec('sticky', 'Sticky', 'pattern', 'Sticky region helpers for table headers or call-to-action blocks.'),
  createSpec('button-social', 'Button Social', 'extra', 'Social auth button bundle reusing Dieter Button primitives.'),
  createSpec('datapoint', 'Datapoint', 'extra', 'Tiny metric display aligning numeric typography scales.'),
  createSpec('date-input', 'Date Input', 'extra', 'Wrapper around native date input with Dieter adornments.'),
  createSpec('indicator', 'Indicator', 'extra', 'Status dot/pill for presence or availability states.'),
  createSpec('pulsar', 'Pulsar', 'extra', 'Animated attention ring honoring prefers-reduced-motion.'),
];

export const componentIndex = new Map(componentDocs.map((spec) => [spec.id, spec] as const));

const assignSpec = (id: string, mutate: (spec: ComponentDocSpec) => void) => {
  const spec = componentIndex.get(id);
  if (spec) {
    mutate(spec);
  }
};

assignSpec('badge', (spec) => {
  spec.css = ['../css/components/primitives/badge.css'];
  spec.anatomy = [
    '`<span class="diet-badge">` wrapper',
    'Optional `<span class="diet-badge__icon">` for leading iconography',
    'Optional `<button class="diet-badge__dismiss">` for close affordances (aria-label required)',
  ];
  spec.grid = {
    heading: 'Types × tones',
    sizes: ['sm', 'md', 'lg'],
    variants: [
      {
        name: 'Types & washes',
        description: 'Info, success, warning, error, neutral, and recommendation badges across size presets plus subtle, outline, and wash treatments.',
        demoPath: '../html/components/badge-grid.html',
      },
    ],
  };
  spec.states = [
    { name: 'Interactive outline', demoPath: '../html/components/badge-state-interactive.html', notes: 'When badges behave like toggles, add `data-interactive="true"` with tabindex so keyboard focus works.' },
    { name: 'Icon with assistive markup', demoPath: '../html/components/badge-state-icon.html', notes: 'Icons live in `<span class="diet-badge__icon">` and stay `aria-hidden`.' },
    { name: 'Dismiss affordance', demoPath: '../html/components/badge-state-dismiss.html', notes: 'Buttons inside badges require `aria-label` copy describing the action.' },
    { name: 'Subtle tone', demoPath: '../html/components/badge-state-subtle.html' },
    { name: 'Outline tone', demoPath: '../html/components/badge-state-outline.html' },
  ];
  spec.examples = [{ title: 'Inline usage', htmlPath: '../html/components/badge-snippet.html' }];
  spec.ai = {
    classNames: ['diet-badge', 'diet-badge__icon', 'diet-badge__dismiss'],
    markup: [
      '<span class="diet-badge" data-type="info">New</span>',
      '<span class="diet-badge" data-type="warning" data-tone="outline" data-interactive="true" tabindex="0">Resolve</span>',
    ],
    states: ['data-type="info|success|warning|error|neutral|recommendation"', 'data-tone="solid|subtle|outline|wash-light|wash-dark"', 'data-size="sm|md|lg"', 'data-interactive="true"', 'data-footprint="text-only|icon-only"'],
    tokens: ['--role-primary-bg', '--role-primary-text', '--role-success-bg', '--role-success-text', '--role-warn-bg', '--role-warn-text', '--role-danger-bg', '--role-danger-text', '--role-border', '--space-2', '--space-3', '--space-4', '--radius-4', '--fs-11', '--fs-12', '--fs-13', '--focus-ring-color'],
    aria: {
      attributes: ['aria-label (required when footprint is icon-only)'],
    },
    selectors: ['.diet-badge', '.diet-badge__dismiss'],
    doNots: [
      'Do not hardcode colors; rely on Dieter role tokens.',
      'Do not remove uppercase styling when badge communicates status.',
      'Do not place interactive markup inside the badge without adding `data-interactive="true"` and tabindex/focus handling.',
    ],
  };
});

assignSpec('box', (spec) => {
  spec.anatomy = [
    '`<div class="diet-box">` root container',
    'Optional `<div class="diet-box__header">` for headlines',
    '`<div class="diet-box__body">` for supporting copy',
    'Optional `<div class="diet-box__footer">` for meta/actions',
  ];
  spec.grid = {
    heading: 'Surface treatments × padding',
    sizes: ['none', 'sm', 'md', 'lg'],
    variants: [
      {
        name: 'Surface options',
        description: 'Base, raised, and sunken treatments across padding presets.',
        demoPath: '../html/components/box-grid.html?raw',
      },
    ],
  };
  spec.states = [
    { name: 'Narrow layout', demoPath: '../html/components/box-state-narrow.html?raw', notes: '`data-width="narrow"` clamps the container for side rails.' },
    { name: 'Inline content', demoPath: '../html/components/box-state-content.html?raw', notes: '`data-width="content"` shrink-wraps the box around its children.' },
    { name: 'Borderless', demoPath: '../html/components/box-state-borderless.html?raw', notes: 'Use `data-border="none"` when nesting boxes inside other surfaces.' },
  ];
  spec.examples = [{ title: 'Card snippet', htmlPath: '../html/components/box-snippet.html?raw' }];
  spec.ai = {
    classNames: ['diet-box', 'diet-box__header', 'diet-box__body', 'diet-box__footer'],
    markup: ['<div class="diet-box" data-padding="md">…</div>'],
    states: ['data-padding="none|sm|md|lg"', 'data-surface="raised|sunken"', 'data-border="none"', 'data-width="narrow|content"'],
    tokens: ['--space-3', '--space-4', '--space-6', '--role-surface-bg', '--role-border', '--radius-4'],
    aria: {},
    selectors: ['.diet-box', '.diet-box__header', '.diet-box__body', '.diet-box__footer'],
    doNots: [
      'Do not hardcode padding; use `data-padding` variants.',
      'Avoid custom shadows—use `data-surface="raised"` instead.',
    ],
  };
});

assignSpec('divider', (spec) => {
  spec.css = ['../css/components/primitives/divider.css'];
  spec.anatomy = [
    '`<hr class="diet-divider">` for horizontal separators',
    'Optional `<div class="diet-divider" role="separator" aria-orientation="vertical">` for vertical dividers embedded inline',
  ];
  spec.grid = {
    heading: 'Orientation × thickness',
    sizes: ['Hairline', 'Medium', 'Heavy'],
    variants: [
      {
        name: 'Presets',
        description: 'Horizontal and vertical dividers using clamp, thickness, and tone modifiers.',
        demoPath: '../html/components/divider-grid.html',
      },
    ],
  };
  spec.states = [
    {
      name: 'Vertical toolbar',
      demoPath: '../html/components/divider-state-vertical.html',
      notes: 'Apply `role="separator"` with `aria-orientation="vertical"` when rendering as a `<div>`. ',
    },
    {
      name: 'Inset layout',
      demoPath: '../html/components/divider-state-inset.html',
      notes: 'Align to container gutters with `data-align="inset"` and spacing tokens.',
    },
    {
      name: 'Strong emphasis',
      demoPath: '../html/components/divider-state-strong.html',
      notes: 'Use `data-tone="strong"` sparingly for totals or destructive groupings.',
    },
  ];
  spec.examples = [
    { title: 'Metric summary snippet', htmlPath: '../html/components/divider-snippet.html' },
  ];
  spec.ai = {
    classNames: ['diet-divider'],
    markup: [
      '<hr class="diet-divider" />',
      '<div class="diet-divider" role="separator" aria-orientation="vertical"></div>',
    ],
    states: [
      'data-orientation="horizontal|vertical"',
      'data-align="content|inset"',
      'data-spacing="none|sm|lg"',
      'data-tone="subtle|strong"',
      'data-thickness="hairline|medium|heavy"',
    ],
    tokens: ['--role-border', '--space-3', '--space-4', '--space-6'],
    aria: {
      role: 'separator',
      attributes: ['aria-orientation="vertical" (required for inline/vertical usage)'],
    },
    selectors: ['.diet-divider', '.diet-divider[data-orientation="vertical"]'],
    doNots: [
      'Do not hand-roll margins; rely on `data-spacing` to adjust gaps.',
      'Avoid omitting `aria-orientation` on vertical dividers rendered as `<div>`.',
      'Do not override divider color outside Dieter tokens.',
    ],
  };
});

assignSpec('container', (spec) => {
  spec.css = ['../css/components/primitives/container.css'];
  spec.anatomy = ['`<section class="diet-container">` layout wrapper providing clamp + gutters'];
  spec.grid = {
    heading: 'Width presets',
    sizes: ['sm', 'md', 'lg', 'xl'],
    variants: [
      {
        name: 'Clamp widths',
        description: 'Responsive max-width presets for primary layout breakpoints.',
        demoPath: '../html/components/container-grid.html',
      },
    ],
  };
  spec.states = [
    { name: 'Full bleed', demoPath: '../html/components/container-state-full.html', notes: '`data-width="full"` for hero/stripe sections.' },
    { name: 'Centered copy', demoPath: '../html/components/container-state-center.html', notes: '`data-align="center"` for marketing headers.' },
    { name: 'No padding', demoPath: '../html/components/container-state-nopad.html', notes: 'Strip padding when parent already manages gutters.' },
  ];
  spec.examples = [{ title: 'Page section snippet', htmlPath: '../html/components/container-snippet.html' }];
  spec.ai = {
    classNames: ['diet-container'],
    markup: ['<section class="diet-container" data-width="lg" data-padding="md">…</section>'],
    states: ['data-width="sm|md|lg|xl|full"', 'data-padding="none|sm|md|lg"', 'data-align="left|center"'],
    tokens: ['--space-4', '--space-5', '--space-6', '--space-8', '--space-9', '--container-width-sm', '--container-width-md', '--container-width-lg', '--container-width-xl'],
    aria: {},
    selectors: ['.diet-container'],
    doNots: [
      'Avoid nesting multiple containers when one will do.',
      'Do not override padding with custom CSS—use data attributes.',
      'Do not hand-code custom breakpoints; override the component width tokens when necessary.',
    ],
  };
});

assignSpec('link', (spec) => {
  spec.css = ['../css/components/primitives/link.css'];
  spec.anatomy = [
    '`<a class="diet-link">` anchor with optional `data-variant` for tone',
    'Optional inline SVG icon to communicate external destinations',
  ];
  spec.grid = {
    heading: 'Context × underline',
    sizes: ['Inline copy', 'Standalone treatments'],
    variants: [
      {
        name: 'Inline & standalone examples',
        description: 'Shows default, subtle, inverse, hover-only underline, and danger usage.',
        demoPath: '../html/components/link-grid.html',
      },
    ],
  };
  spec.states = [
    {
      name: 'External link with icon',
      demoPath: '../html/components/link-state-external.html',
      notes: 'Include visually hidden copy describing new tab or external destinations.',
    },
    {
      name: 'Focus styles',
      demoPath: '../html/components/link-state-focus.html',
      notes: 'Focus-visible keeps underline and uses Dieter focus ring tokens.',
    },
  ];
  spec.examples = [
    { title: 'Marketing snippet', htmlPath: '../html/components/link-snippet.html' },
  ];
  spec.ai = {
    classNames: ['diet-link'],
    markup: ['<a class="diet-link" data-variant="default" href="#">Link text</a>'],
    states: [
      'data-variant="default|subtle|inverse|shopping|danger"',
      'data-underline="hover|none"',
      'data-weight="regular|bold"',
      'data-icon="leading"',
    ],
    tokens: ['--color-accent', '--focus-ring-color', '--space-2', '--fs-14'],
    aria: {
      attributes: ['aria-current="page" for active navigation items'],
    },
    selectors: ['.diet-link', '.diet-link svg'],
    doNots: [
      'Do not render external icons without accessible copy describing the behavior.',
      'Avoid overriding colors with raw hex values—use Dieter variants.',
      'Do not remove hover feedback when underline is disabled; provide alternate affordance.',
    ],
  };
});

assignSpec('spinner', (spec) => {
  spec.css = ['../css/components/primitives/spinner.css'];
  spec.anatomy = [
    '`<div class="diet-spinner">` root with border-based animation',
    'Optional inline label using `.diet-spinner__label` for status messaging',
  ];
  spec.grid = {
    heading: 'Sizes × tones',
    sizes: ['sm', 'md', 'lg'],
    variants: [
      {
        name: 'Inline spinners',
        description: 'Demonstrates size presets and inverse tone for dark surfaces.',
        demoPath: '../html/components/spinner-grid.html',
      },
    ],
  };
  spec.states = [
    {
      name: 'Labeled status',
      demoPath: '../html/components/spinner-state-labeled.html',
      notes: 'Use `role="status"` with visually hidden text for screen readers.',
    },
    {
      name: 'Inline layout',
      demoPath: '../html/components/spinner-state-inline.html',
      notes: '`data-layout="inline"` pairs spinner with supporting copy.',
    },
  ];
  spec.examples = [
    { title: 'Upload toast', htmlPath: '../html/components/spinner-snippet.html' },
  ];
  spec.ai = {
    classNames: ['diet-spinner', 'diet-spinner__label'],
    markup: ['<div class="diet-spinner" role="status"><span class="visually-hidden">Loading…</span></div>'],
    states: [
      'data-size="sm|md|lg"',
      'data-tone="neutral|inverse"',
      'data-state="paused"',
      'data-layout="inline"',
    ],
    tokens: ['--color-accent', '--space-3', '--fs-13'],
    aria: {
      role: 'status',
      attributes: ['aria-live="polite" for non-blocking operations'],
    },
    selectors: ['.diet-spinner', '.diet-spinner__label'],
    doNots: [
      'Do not rely on color alone to communicate loading state—include aria-live text.',
      'Avoid increasing animation speed beyond spec; respect reduced-motion preferences.',
      'Do not replace the spinner with GIFs or custom SVGs without design approval.',
    ],
  };
});

assignSpec('input', (spec) => {
  spec.css = ['../css/components/forms/input.css'];
  spec.anatomy = [
    '`<label class="diet-input">` wrapper providing label + helper layout',
    '`.diet-input__control` flex container for field and affixes',
    '`.diet-input__field` actual `<input>` element',
    'Optional `.diet-input__helper` and `.diet-input__counter` for supporting text',
  ];
  spec.grid = {
    heading: 'Sizes × affixes',
    sizes: ['sm', 'md', 'lg'],
    variants: [
      {
        name: 'Size presets',
        description: 'Shows compact through large with consistent padding and radius.',
        demoPath: '../html/components/input-grid.html',
      },
    ],
  };
  spec.states = [
    {
      name: 'Error state',
      demoPath: '../html/components/input-state-error.html',
      notes: 'Use `data-state="error"` with helper text tied via `aria-describedby`.',
    },
    {
      name: 'Disabled',
      demoPath: '../html/components/input-state-disabled.html',
      notes: '`data-state="disabled"` lowers contrast and preserves value for read-only.',
    },
  ];
  spec.examples = [
    { title: 'Form snippet', htmlPath: '../html/components/input-snippet.html' },
  ];
  spec.ai = {
    classNames: ['diet-input', 'diet-input__label', 'diet-input__control', 'diet-input__field', 'diet-input__helper', 'diet-input__affix'],
    markup: ['<label class="diet-input"><span class="diet-input__label">Label</span><span class="diet-input__control"><input class="diet-input__field" /></span></label>'],
    states: [
      'data-size="sm|md|lg"',
      'data-state="error|success|disabled"',
      'data-affix="start"',
      'data-alignment="inline"',
    ],
    tokens: ['--space-2', '--space-3', '--space-4', '--control-radius-sm', '--control-radius-md', '--color-accent', '--role-danger-bg'],
    aria: {
      attributes: ['aria-describedby for helper or error text'],
    },
    selectors: ['.diet-input', '.diet-input__field'],
    doNots: [
      'Do not remove labels—use visually hidden text if needed.',
      'Avoid custom pixel padding; rely on size presets.',
      'Do not mix inline alignment without updating form layout grid.',
    ],
  };
});

assignSpec('textarea', (spec) => {
  spec.css = ['../css/components/forms/textarea.css'];
  spec.anatomy = [
    '`<label class="diet-textarea">` wrapper with label + helper layout',
    '`.diet-textarea__field` `<textarea>` element supporting resize modifiers',
    'Optional `.diet-textarea__helper` and `.diet-textarea__counter` for guidance',
  ];
  spec.grid = {
    heading: 'Resize options',
    sizes: ['default', 'auto'],
    variants: [
      {
        name: 'Baseline & auto-resize',
        description: 'Default textarea plus auto height variant for longer copy.',
        demoPath: '../html/components/textarea-grid.html',
      },
    ],
  };
  spec.states = [
    {
      name: 'Error messaging',
      demoPath: '../html/components/textarea-state-error.html',
      notes: 'Helper text with `data-tone="error"` communicates validation issues.',
    },
  ];
  spec.examples = [
    { title: 'Content snippet', htmlPath: '../html/components/textarea-snippet.html' },
  ];
  spec.ai = {
    classNames: ['diet-textarea', 'diet-textarea__label', 'diet-textarea__field', 'diet-textarea__helper', 'diet-textarea__counter'],
    markup: ['<label class="diet-textarea"><span class="diet-textarea__label">Label</span><textarea class="diet-textarea__field"></textarea></label>'],
    states: [
      'data-state="error|success|disabled"',
      'data-resize="none|vertical|auto"',
    ],
    tokens: ['--space-3', '--space-4', '--control-radius-md', '--color-accent', '--role-danger-bg'],
    aria: {
      attributes: ['aria-describedby for helper/error text'],
    },
    selectors: ['.diet-textarea', '.diet-textarea__field'],
    doNots: [
      'Do not rely on placeholder as the only label.',
      'Avoid disabling resize without providing ample height.',
      'Do not mix manual inline styles for spacing—use Dieter tokens.',
    ],
  };
});

// GROUP 2: Form Controls & Overlays
assignSpec('checkbox', (spec) => {
  spec.css = ['../css/components/forms/checkbox.css'];
  spec.anatomy = [
    '`<label class="diet-checkbox">` wrapper with inline-grid layout',
    '`<input class="diet-checkbox__input">` native checkbox (visually hidden)',
    '`<span class="diet-checkbox__box">` visual checkbox square',
    '`<span class="diet-checkbox__icon">` checkmark SVG (animated)',
    'Optional `<span class="diet-checkbox__indeterminate">` for mixed state',
    'Optional `<span class="diet-checkbox__meta">` wrapping label + description',
    '`<span class="diet-checkbox__label">` text label',
    'Optional `<span class="diet-checkbox__description">` helper copy',
  ];
  spec.grid = {
    heading: 'Sizes × States',
    sizes: ['sm (16px)', 'md (20px)', 'lg (24px)'],
    variants: [
      { name: 'Sizes & States', description: 'Small, medium, large with unchecked, checked, indeterminate, disabled, and error states.', demoPath: '../html/components/checkbox-grid.html' },
    ],
  };
  spec.states = [
    { name: 'Checked', demoPath: '../html/components/checkbox-grid.html', notes: 'Blue background with white checkmark when :checked' },
    { name: 'Indeterminate', demoPath: '../html/components/checkbox-grid.html', notes: 'Set via JS: element.indeterminate = true' },
    { name: 'Disabled', demoPath: '../html/components/checkbox-grid.html', notes: 'Reduced opacity, cursor: not-allowed' },
    { name: 'Error', demoPath: '../html/components/checkbox-grid.html', notes: 'Red border via data-state="error"' },
  ];
  spec.examples = [{ title: 'Form usage', htmlPath: '../html/components/checkbox-snippet.html' }];
  spec.ai = {
    classNames: ['diet-checkbox', 'diet-checkbox__input', 'diet-checkbox__box', 'diet-checkbox__icon', 'diet-checkbox__indeterminate', 'diet-checkbox__label', 'diet-checkbox__meta', 'diet-checkbox__description', 'diet-checkbox__helper'],
    markup: [
      '<label class="diet-checkbox"><input class="diet-checkbox__input" type="checkbox" /><span class="diet-checkbox__box"><span class="diet-checkbox__icon"><svg>...</svg></span></span><span class="diet-checkbox__label">Label</span></label>',
    ],
    states: ['data-size="sm|md|lg"', 'data-state="error|disabled"', ':checked', ':indeterminate', ':disabled', ':focus-visible'],
    tokens: ['--color-system-blue', '--color-system-gray', '--color-system-white', '--color-system-gray-6', '--color-bg', '--color-text', '--color-text-muted', '--role-danger-bg', '--space-1', '--space-2', '--fs-12', '--fs-14', '--fs-15', '--lh-normal', '--focus-ring-offset', '--focus-ring-width', '--focus-ring-color'],
    aria: {
      attributes: ['aria-describedby for error messages', 'aria-label if label is not visible'],
      keyboard: ['Space'],
    },
    selectors: ['.diet-checkbox', '.diet-checkbox__input:checked + .diet-checkbox__box', '.diet-checkbox__input:indeterminate + .diet-checkbox__box'],
    doNots: [
      'Do not use onClick on the label—rely on native checkbox behavior',
      'Do not forget aria-describedby when showing error messages',
      'Do not hardcode colors—use Dieter color tokens',
    ],
  };
});

assignSpec('radiogroup', (spec) => {
  spec.css = ['../css/components/forms/radiogroup.css'];
  spec.anatomy = [
    '`<div class="diet-radiogroup" role="radiogroup">` container',
    '`<label class="diet-radio">` wrapper for each option',
    '`<input class="diet-radio__input" type="radio">` native radio',
    '`<span class="diet-radio__circle">` visual indicator',
    '`<span class="diet-radio__dot">` inner filled dot',
    '`<span class="diet-radio__label">` text label',
    'Optional `<span class="diet-radio__description">` helper text',
  ];
  spec.grid = {
    heading: 'Layouts × Sizes',
    sizes: ['sm', 'md', 'lg'],
    variants: [
      { name: 'Vertical & Horizontal', description: 'Stack and inline layouts with size presets', demoPath: '../html/components/radiogroup-grid.html' },
    ],
  };
  spec.states = [
    { name: 'Selected', demoPath: '../html/components/radiogroup-grid.html', notes: 'Blue circle with inner dot when :checked' },
    { name: 'Disabled', demoPath: '../html/components/radiogroup-grid.html', notes: 'Reduced opacity for disabled radios' },
    { name: 'Error', demoPath: '../html/components/radiogroup-grid.html', notes: 'Red border via data-state="error"' },
  ];
  spec.examples = [{ title: 'Billing options', htmlPath: '../html/components/radiogroup-snippet.html' }];
  spec.ai = {
    classNames: ['diet-radiogroup', 'diet-radio', 'diet-radio__input', 'diet-radio__circle', 'diet-radio__dot', 'diet-radio__label', 'diet-radio__description'],
    markup: ['<div class="diet-radiogroup" role="radiogroup" aria-label="..."><label class="diet-radio"><input class="diet-radio__input" type="radio" name="group" /><span class="diet-radio__circle"><span class="diet-radio__dot"></span></span><span class="diet-radio__label">Option</span></label></div>'],
    states: ['data-size="sm|md|lg"', 'data-layout="vertical|horizontal"', 'data-state="error"', ':checked', ':disabled'],
    tokens: ['--color-system-blue', '--color-system-gray', '--color-bg', '--color-text', '--space-2', '--space-4', '--fs-14'],
    aria: {
      role: 'radiogroup',
      attributes: ['aria-label on radiogroup', 'aria-describedby for errors'],
      keyboard: ['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space'],
    },
    selectors: ['.diet-radiogroup', '.diet-radio__input:checked + .diet-radio__circle'],
    doNots: [
      'Do not forget role="radiogroup" and aria-label',
      'Do not use same name across different radiogroups',
      'Do not skip keyboard navigation support',
    ],
  };
});

assignSpec('select', (spec) => {
  spec.css = ['../css/components/forms/select.css'];
  spec.anatomy = [
    '`<div class="diet-select">` wrapper',
    '`<select class="diet-select__native">` native select element',
    '`<span class="diet-select__icon">` dropdown chevron icon',
    'Optional `<label class="diet-select__label">` label above select',
    'Optional `<span class="diet-select__helper">` helper/error text below',
  ];
  spec.grid = {
    heading: 'Sizes × States',
    sizes: ['sm', 'md', 'lg'],
    variants: [
      { name: 'Basic selects', description: 'Size presets with placeholder and filled states', demoPath: '../html/components/select-grid.html' },
    ],
  };
  spec.states = [
    { name: 'Filled', demoPath: '../html/components/select-grid.html', notes: 'Shows selected value' },
    { name: 'Disabled', demoPath: '../html/components/select-grid.html', notes: 'Reduced opacity, no pointer events' },
    { name: 'Error', demoPath: '../html/components/select-grid.html', notes: 'Red border with helper text' },
  ];
  spec.examples = [{ title: 'Country selector', htmlPath: '../html/components/select-snippet.html' }];
  spec.ai = {
    classNames: ['diet-select', 'diet-select__native', 'diet-select__icon', 'diet-select__label', 'diet-select__helper'],
    markup: ['<div class="diet-select"><select class="diet-select__native"><option value="">Choose...</option><option value="1">Option 1</option></select><span class="diet-select__icon"><svg>...</svg></span></div>'],
    states: ['data-size="sm|md|lg"', 'data-state="error"', ':disabled', ':focus'],
    tokens: ['--color-system-gray', '--color-bg', '--color-text', '--role-border', '--role-danger-bg', '--space-2', '--space-3', '--fs-14'],
    aria: {
      attributes: ['aria-label or associated <label> element', 'aria-describedby for errors'],
    },
    selectors: ['.diet-select', '.diet-select__native:focus'],
    doNots: [
      'Do not hide native select—style it directly for accessibility',
      'Do not forget focus states',
      'Do not omit label or aria-label',
    ],
  };
});

assignSpec('switch', (spec) => {
  spec.css = ['../css/components/forms/switch.css'];
  spec.anatomy = [
    '`<label class="diet-switch">` wrapper',
    '`<input class="diet-switch__input" type="checkbox" role="switch">` native checkbox with switch role',
    '`<span class="diet-switch__track">` background track',
    '`<span class="diet-switch__thumb">` sliding toggle',
    '`<span class="diet-switch__label">` text label',
  ];
  spec.grid = {
    heading: 'Sizes × States',
    sizes: ['sm', 'md', 'lg'],
    variants: [
      { name: 'Toggle switches', description: 'iOS-style switches in multiple sizes', demoPath: '../html/components/switch-grid.html' },
    ],
  };
  spec.states = [
    { name: 'On', demoPath: '../html/components/switch-grid.html', notes: 'Blue track with thumb on right when :checked' },
    { name: 'Off', demoPath: '../html/components/switch-grid.html', notes: 'Gray track with thumb on left' },
    { name: 'Disabled', demoPath: '../html/components/switch-grid.html', notes: 'Reduced opacity' },
  ];
  spec.examples = [{ title: 'Settings panel', htmlPath: '../html/components/switch-snippet.html' }];
  spec.ai = {
    classNames: ['diet-switch', 'diet-switch__input', 'diet-switch__track', 'diet-switch__thumb', 'diet-switch__label'],
    markup: ['<label class="diet-switch"><input class="diet-switch__input" type="checkbox" role="switch" /><span class="diet-switch__track"><span class="diet-switch__thumb"></span></span><span class="diet-switch__label">Enable</span></label>'],
    states: ['data-size="sm|md|lg"', ':checked', ':disabled'],
    tokens: ['--color-system-blue', '--color-system-gray-5', '--color-system-white', '--color-bg', '--space-2', '--fs-14'],
    aria: {
      role: 'switch',
      attributes: ['aria-checked mirrors checked state', 'aria-label if no visible label'],
    },
    selectors: ['.diet-switch', '.diet-switch__input:checked + .diet-switch__track'],
    doNots: [
      'Do not forget role="switch" on input',
      'Do not use for irreversible actions—switches are for instant state changes',
      'Do not skip smooth animations—they communicate state change',
    ],
  };
});

assignSpec('fieldset', (spec) => {
  spec.css = ['../css/components/forms/fieldset.css'];
  spec.anatomy = [
    '`<fieldset class="diet-fieldset">` native grouping element',
    '`<legend class="diet-fieldset__legend">` accessible group label',
    '`<div class="diet-fieldset__content">` inner wrapper for controls',
    'Optional `<span class="diet-fieldset__helper">` descriptive text',
  ];
  spec.grid = {
    heading: 'Layouts',
    sizes: ['Vertical stack', 'Horizontal row'],
    variants: [
      { name: 'Form groups', description: 'Vertical and horizontal fieldset layouts', demoPath: '../html/components/fieldset-grid.html' },
    ],
  };
  spec.states = [
    { name: 'Default', demoPath: '../html/components/fieldset-grid.html', notes: 'Standard border and spacing' },
    { name: 'Disabled', demoPath: '../html/components/fieldset-grid.html', notes: 'All children disabled via fieldset disabled attribute' },
  ];
  spec.examples = [{ title: 'Account settings', htmlPath: '../html/components/fieldset-snippet.html' }];
  spec.ai = {
    classNames: ['diet-fieldset', 'diet-fieldset__legend', 'diet-fieldset__content', 'diet-fieldset__helper'],
    markup: ['<fieldset class="diet-fieldset"><legend class="diet-fieldset__legend">Group title</legend><div class="diet-fieldset__content"><!-- controls --></div></fieldset>'],
    states: ['data-layout="vertical|horizontal"', ':disabled'],
    tokens: ['--role-border', '--color-text', '--space-4', '--space-6', '--fs-14', '--fs-16'],
    aria: {},
    selectors: ['.diet-fieldset', 'fieldset:disabled .diet-fieldset__content'],
    doNots: [
      'Do not omit <legend>—it provides accessible grouping',
      'Do not nest fieldsets unnecessarily',
    ],
  };
});

assignSpec('modal', (spec) => {
  spec.css = ['../css/components/overlays/modal.css'];
  spec.anatomy = [
    '`<div class="diet-modal" role="dialog" aria-modal="true">` dialog container',
    '`<div class="diet-modal__overlay">` backdrop (dimmed background)',
    '`<div class="diet-modal__content">` main content box',
    '`<div class="diet-modal__header">` title area with close button',
    '`<div class="diet-modal__body">` scrollable content',
    '`<div class="diet-modal__footer">` action buttons',
  ];
  spec.grid = {
    heading: 'Sizes',
    sizes: ['sm (480px)', 'md (640px)', 'lg (960px)'],
    variants: [
      { name: 'Modal sizes', description: 'Small, medium, and large modal widths', demoPath: '../html/components/modal-grid.html' },
    ],
  };
  spec.states = [
    { name: 'Open', demoPath: '../html/components/modal-grid.html', notes: 'Visible with backdrop, focus trapped' },
    { name: 'Closed', demoPath: '../html/components/modal-grid.html', notes: 'Hidden via display:none or data-state' },
  ];
  spec.examples = [{ title: 'Confirmation dialog', htmlPath: '../html/components/modal-snippet.html' }];
  spec.ai = {
    classNames: ['diet-modal', 'diet-modal__overlay', 'diet-modal__content', 'diet-modal__header', 'diet-modal__body', 'diet-modal__footer'],
    markup: ['<div class="diet-modal" role="dialog" aria-modal="true" aria-labelledby="modal-title"><div class="diet-modal__overlay"></div><div class="diet-modal__content"><div class="diet-modal__header"><h2 id="modal-title">Title</h2><button aria-label="Close">×</button></div><div class="diet-modal__body">Content</div></div></div>'],
    states: ['data-size="sm|md|lg"', 'data-state="open|closed"'],
    tokens: ['--color-bg', '--color-surface', '--role-border', '--space-4', '--space-6', '--radius-4'],
    aria: {
      role: 'dialog',
      attributes: ['aria-modal="true"', 'aria-labelledby pointing to title', 'aria-describedby for body content'],
      keyboard: ['Escape'],
      focus: 'Trap focus within modal when open',
    },
    selectors: ['.diet-modal[data-state="open"]', '.diet-modal__overlay'],
    doNots: [
      'Do not forget aria-modal="true" and role="dialog"',
      'Do not allow background scroll when modal is open',
      'Do not skip Escape key dismissal',
      'Do not forget to return focus to trigger element on close',
    ],
  };
});

assignSpec('overlay-panel', (spec) => {
  spec.css = ['../css/components/overlays/overlay-panel.css'];
  spec.anatomy = [
    '`<div class="diet-overlay-panel" role="dialog">` panel container',
    '`<div class="diet-overlay-panel__backdrop">` optional dimmed background',
    '`<div class="diet-overlay-panel__content">` sliding drawer',
    '`<div class="diet-overlay-panel__header">` title with close button',
    '`<div class="diet-overlay-panel__body">` scrollable content',
  ];
  spec.grid = {
    heading: 'Positions',
    sizes: ['left', 'right', 'top', 'bottom'],
    variants: [
      { name: 'Slide directions', description: 'Panels sliding from each edge', demoPath: '../html/components/overlay-panel-grid.html' },
    ],
  };
  spec.states = [
    { name: 'Open', demoPath: '../html/components/overlay-panel-grid.html', notes: 'Slides in from edge with backdrop' },
    { name: 'Closed', demoPath: '../html/components/overlay-panel-grid.html', notes: 'Off-screen' },
  ];
  spec.examples = [{ title: 'Filters panel', htmlPath: '../html/components/overlay-panel-snippet.html' }];
  spec.ai = {
    classNames: ['diet-overlay-panel', 'diet-overlay-panel__backdrop', 'diet-overlay-panel__content', 'diet-overlay-panel__header', 'diet-overlay-panel__body'],
    markup: ['<div class="diet-overlay-panel" role="dialog" data-position="right"><div class="diet-overlay-panel__backdrop"></div><div class="diet-overlay-panel__content"><div class="diet-overlay-panel__header"><h2>Title</h2><button aria-label="Close">×</button></div><div class="diet-overlay-panel__body">Content</div></div></div>'],
    states: ['data-position="left|right|top|bottom"', 'data-state="open|closed"'],
    tokens: ['--color-bg', '--color-surface', '--space-4', '--space-6'],
    aria: {
      role: 'dialog',
      attributes: ['aria-labelledby for title', 'aria-modal="true" if backdrop dims background'],
      keyboard: ['Escape'],
    },
    selectors: ['.diet-overlay-panel[data-state="open"]', '.diet-overlay-panel__backdrop'],
    doNots: [
      'Do not forget aria-labelledby',
      'Do not skip focus trap when backdrop is present',
      'Do not use overly long slide animations—keep under 300ms',
    ],
  };
});

assignSpec('popover', (spec) => {
  spec.css = ['../css/components/overlays/popover.css'];
  spec.anatomy = [
    '`<div class="diet-popover">` popover container',
    '`<div class="diet-popover__arrow">` pointing triangle',
    '`<div class="diet-popover__content">` main content box',
  ];
  spec.grid = {
    heading: 'Placements',
    sizes: ['top', 'right', 'bottom', 'left'],
    variants: [
      { name: 'Popover positions', description: 'Arrow positions for all four edges', demoPath: '../html/components/popover-grid.html' },
    ],
  };
  spec.states = [
    { name: 'Open', demoPath: '../html/components/popover-grid.html', notes: 'Visible, anchored to trigger' },
    { name: 'Closed', demoPath: '../html/components/popover-grid.html', notes: 'Hidden' },
  ];
  spec.examples = [{ title: 'Help popover', htmlPath: '../html/components/popover-snippet.html' }];
  spec.ai = {
    classNames: ['diet-popover', 'diet-popover__arrow', 'diet-popover__content'],
    markup: ['<div class="diet-popover" data-placement="top"><div class="diet-popover__arrow"></div><div class="diet-popover__content">Popover text</div></div>'],
    states: ['data-placement="top|right|bottom|left"', 'data-state="open|closed"'],
    tokens: ['--color-surface', '--color-text', '--role-border', '--space-3', '--space-4', '--fs-12', '--radius-4'],
    aria: {
      attributes: ['aria-describedby on trigger pointing to popover id', 'role="tooltip" if non-interactive'],
    },
    selectors: ['.diet-popover[data-state="open"]', '.diet-popover__arrow'],
    doNots: [
      'Do not place interactive content in role="tooltip"—use role="dialog" instead',
      'Do not forget to close popover on Escape or outside click',
      'Do not hardcode positioning—use data-placement attributes',
    ],
  };
});

assignSpec('tooltip', (spec) => {
  spec.css = ['../css/components/overlays/tooltip.css'];
  spec.anatomy = [
    '`<div class="diet-tooltip" role="tooltip">` tooltip container',
    '`<div class="diet-tooltip__arrow">` pointing triangle',
    '`<div class="diet-tooltip__content">` text content',
  ];
  spec.grid = {
    heading: 'Placements',
    sizes: ['top', 'right', 'bottom', 'left'],
    variants: [
      { name: 'Tooltip positions', description: 'Compact tooltips on all edges', demoPath: '../html/components/tooltip-grid.html' },
    ],
  };
  spec.states = [
    { name: 'Visible', demoPath: '../html/components/tooltip-grid.html', notes: 'Shows on hover/focus' },
    { name: 'Hidden', demoPath: '../html/components/tooltip-grid.html', notes: 'Hidden by default' },
  ];
  spec.examples = [{ title: 'Icon tooltips', htmlPath: '../html/components/tooltip-snippet.html' }];
  spec.ai = {
    classNames: ['diet-tooltip', 'diet-tooltip__arrow', 'diet-tooltip__content'],
    markup: ['<div class="diet-tooltip" role="tooltip" data-placement="top" id="tooltip-1"><div class="diet-tooltip__arrow"></div><div class="diet-tooltip__content">Tooltip text</div></div>'],
    states: ['data-placement="top|right|bottom|left"', 'data-state="visible|hidden"'],
    tokens: ['--color-system-black', '--color-system-white', '--space-2', '--space-3', '--fs-11', '--radius-4'],
    aria: {
      role: 'tooltip',
      attributes: ['id for reference from aria-describedby on trigger'],
    },
    selectors: ['.diet-tooltip[data-state="visible"]', '.diet-tooltip__arrow'],
    doNots: [
      'Do not place interactive content in tooltips—use popover instead',
      'Do not show tooltips on mobile without tap-to-dismiss',
      'Do not make tooltips too wide—max 240px',
    ],
  };
});

export const navGroups: NavGroup[] = [
  {
    id: 'overview',
    title: '',
    items: [{ id: 'home', title: 'Home', path: '#/', kind: 'home', summary: 'Component gallery overview.' }],
  },
  {
    id: 'dieter',
    title: 'Dieter Components',
    items: dieterItems,
  },
  {
    id: 'lab',
    title: 'Lab',
    items: componentDocs.map((spec) => ({
      id: spec.id,
      title: spec.title,
      path: `#/components/${spec.id}`,
      kind: 'component',
      summary: spec.summary,
    })),
  },
];

export const routeIndex = new Map<string, NavItem>();
navGroups.forEach((group) => {
  group.items.forEach((item) => routeIndex.set(item.path, item));
});

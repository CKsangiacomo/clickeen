# NewDieterLAB — Codex Execution Plan (Lab‑Only)

**Owner:** Codex AI
**Stakeholder:** CEO (Human)
**Location:** `lab/NewDieterLAB/` (no writes outside this folder)
**Objective:** Build a Gestalt-style **CSS-first** documentation + component gallery prototype grounded entirely in Dieter. Baseline Dieter previews (`src/html/dieter/**`) are complete and frozen for parity; see `newcomponentsSept25.md` for the active plan covering new Lab components. You may import/reference Dieter assets for fidelity, but treat everything under `dieter/` as read-only—no modifications allowed.

---

## Non‑negotiable guardrails

* ✅ **Isolation:** All code, assets, and build artifacts live under `lab/NewDieterLAB/`.
* ✅ **Source usage:** You may **read/import** Dieter assets (tokens, component CSS) to ensure fidelity, but **never modify** files under `dieter/` or write to those directories. Treat them as read-only inputs.
* ✅ **Stack:** Vanilla HTML + TypeScript served by Vite; Dieter-style CSS only (custom properties, cascade layers). No React, JSX, or component frameworks.
* ✅ **Browsers:** Evergreen only.
* ✅ **A11y baseline:** Keyboard, focus rings, roles/ARIA for interactive components.
* ✅ **Dieter alignment:** Every utility/component must follow `documentation/systems/Dieter.md` (tokens, spacing, control heights, theming). No new tokens or behaviors unless the doc is updated first.
* ✅ **Gestalt inspiration only:** You may reference `TMP_OLDREPO/gestalt/` (local Gestalt docs dump) for layout and content inspiration. Do **not** copy Gestalt tokens, class names, or JS—translate learnings back into Dieter naming and tokens.
* ✅ **Authority chain:** `documentation/CRITICAL-TECHPHASES/Techphases-Phase1Specs.md` → `documentation/systems/Dieter.md` → this lab plan. If Gestalt or any new idea conflicts, update the Dieter docs first, then code.
* ✅ **STOP rule:** When a contract, token, or behavior isn’t defined in Techphases or Dieter.md, label it `MISSING` in docs, log it in `DECISIONS.md`, and halt implementation until approval—never invent upstream specs.
* ✅ **Autonomy protocol:** Favor non-blocking commands; avoid anything that prompts for approvals, escalations, or long-running watchers. If a required action might pause execution, document the need in `DECISIONS.md`, make the safest assumption, and continue—human review will happen later.

---

## Deliverables

1. **Baseline Dieter previews**: replicate the current `admin/dietercomponents.html` button/segmented/color/typography demos using plain HTML that imports Dieter CSS bundles (no JS frameworks).
2. **Docs shell** (Gestalt-style) with left nav, sticky header, content column, optional right rail—implemented with vanilla DOM code and Dieter CSS utilities.
3. **Gestalt-inspired lab components**: implement the backlog below as new Dieter CSS contracts (`.diet-*` classes) plus Gestalt-style documentation/views. Each contract lives entirely in this lab and references existing Dieter tokens.
4. **Per-component page**: Visual-first layout mirroring the new lab treatment—component grids (all sizes × variants), state strip, and supporting snippets/tokens/accessibility/tests. Human overview + AI contract (markup requirements, tokens, aria hooks, test strategy) rendered from static JSON/TS data by minimal TypeScript.
5. **Local index.html** to navigate everything (this lab’s homepage) bundling only vanilla JS and CSS via Vite.

---

## Directory layout (create exactly)

```
lab/NewDieterLAB/
  package.json
  vite.config.ts
  index.html
  .eslintrc.cjs
  tsconfig.json
  src/
    main.ts                  # bootstraps nav + routing with vanilla DOM
    router.ts                # tiny hash-based router
    data/
      routes.ts              # nav + component metadata
      dieter.ts              # Dieter showcase descriptors (CSS imports + markup)
    css/
      tokens.css             # light/dark tokens for lab only
      layout.css             # site shell (nav/header/content)
      utilities.css          # helpers (stack, grid, visually-hidden)
      dieter-previews.css    # layout for Dieter showcase examples
    html/
      index.html             # docs shell template fragments
      dieter/
        button.html
        segmented.html
        colors.html
        typography.html
      components/
        badge.html
        box.html
        container.html
        divider.html
        link.html
        spinner.html
        input.html
        textarea.html
        checkbox.html
        radiogroup.html
        select.html
        switch.html
        fieldset.html
        modal.html
        overlay-panel.html
        popover.html
        tooltip.html
        tabs.html
        toast.html
        dropdown.html
        activation-card.html
        banner.html
        help-button.html
        page-header.html
        mask.html
        sticky.html
        button-social.html
        datapoint.html
        date-input.html
        indicator.html
        pulsar.html
```

---

## Setup (one‑time) — follow these steps exactly

1. **Initialize workspace**
   ```bash
   cd lab
   mkdir -p NewDieterLAB && cd NewDieterLAB
   pnpm init -y
   ```
2. **Install runtime + tooling dependencies**
   ```bash
   pnpm add -D vite typescript @types/node eslint @typescript-eslint/parser @typescript-eslint/eslint-plugin vitest @vitest/browser jsdom
   ```
3. **Scaffold Vite project** (overwrite starter files)
   ```bash
   pnpm create vite@latest . -- --template vanilla-ts
   ```
   Always prefer non-interactive commands that exit promptly—no long-running dev servers during setup. Delete any generated files that are not part of the directory layout defined earlier.
4. **Create directory structure** exactly as listed (css/components, html/components, etc.). Add placeholder `.css` files with comments and `.html` demos containing TODO text so imports resolve.
5. **Configure tooling**
   - `tsconfig.json`: ensure `"strict": true`, `"moduleResolution": "bundler"`, `"baseUrl": "./"`, `"types": ["vite/client"]`.
   - `vite.config.ts`: register plain Vite config (no React plugin), expose alias `@dieter` → `<repo>/dieter` for read-only imports, set `server: { open: true }`.
   - `.eslintrc.cjs`: extend `eslint:recommended` + `plugin:@typescript-eslint/recommended`, enable DOM globals, forbid React-specific rules.
   - `package.json` scripts: `{ "dev": "vite", "build": "vite build", "preview": "vite preview", "test": "vitest" }`.
6. **Bootstrap entry files**
   - Replace Vite defaults so `src/main.ts` mounts the docs shell by querying `#app` and injecting HTML from template helpers. No JSX.
   - Create `src/router.ts` to manage hash-based navigation (`#/dieter/button`, `#/components/badge`, etc.).
   - Update root `index.html` to preload `/src/css/tokens.css`, `/src/css/layout.css`, `/src/css/utilities.css` and include an anchor to `../../admin/dietercomponents.html` for parity checks.
7. **Create style scaffolding**
   - `src/css/tokens.css`: copy Dieter light/dark tokens (colors, spacing, control sizes). Include both `@media (prefers-color-scheme: dark)` and `[data-theme="dark"]` overrides.
   - `src/css/layout.css`: implement docs shell grid (260px sidebar + content), sticky header, responsive collapse under 960px.
   - `src/css/utilities.css`: define `.visually-hidden`, `.stack-*` (gap-based spacing), `.grid-*` helpers, and any shared typography/inline code utilities needed.
8. **Define navigation model**
   - Create `src/data/routes.ts` exporting nav groups. First group should be “Dieter Components” with entries for Button, Segmented Control, Color tokens, Typography to mirror the current `admin/dietercomponents.html`.
9. **Document run instructions**
   - Add `README.md` summarizing install/run/test commands and the lab guardrails. Include a note that Gestalt lives at `TMP_OLDREPO/gestalt/` for reference only—do not copy code.

---

## Site shell (docs UX)

**Goal:** Mirror Gestalt’s clarity: left sidebar nav, sticky header, content area, right “On this page”.

**Tasks**

* [ ] Build `layout.css` grid: `260px` sidebar, `1fr` content; sticky header; responsive collapse under 960px.
* [ ] Build `tokens.css`: light/dark CSS variables (bg/fg/muted/primary/success/warning/danger/border/radius/space scale).
* [ ] Build nav model in `src/data/routes.ts` (see Component backlog). Group by category.
* [ ] Implement vanilla shell: `src/main.ts` reads nav data, renders sidebar/content panes, and wires hash-based routing via `src/router.ts`.
* [ ] Recreate Dieter previews: author HTML fragments that import Dieter CSS directly (Button, Segmented, Color, Typography) and ensure markup/focus behavior matches the admin harness.
* [ ] Build `Home` view as a template literal in `src/html/index.html` (consumed by TypeScript) to render tiled component cards with status badges and Dieter showcase tiles.
* [ ] Build `ComponentPage` renderer (pure TypeScript) that injects content in this order: overview blurb → visual demos (size × variant grid, state strip, iframe toggle) → collapsible sections for code snippets, token lists, accessibility notes, test plan.
* [ ] Display a persistent “LAB ONLY — Not production Dieter” banner within the shell header to prevent confusion with the canonical system.
* [ ] For inspiration on layout and docs UX you may inspect `TMP_OLDREPO/gestalt/docs/` (e.g., `AppShell` implementation), but reimplement using Dieter tokens and naming.

---

## Naming contract (authoritative aliases)

| Canonical name | Acceptable aliases | Notes |
| --- | --- | --- |
| Input | TextField | Treat as form control collecting free-form text. |
| Select | SelectList | Single-select form control. `Dropdown` remains action/menu surface. |
| Dropdown | Menu | Command list, not a form field. |
| OverlayPanel | Drawer, Sheet | Sliding panel anchored to viewport edge. |
| ButtonSocial | SocialButton | Reuses Button contract with provider adornments. |

Always use the canonical name in CSS filenames (`input.css`, `dropdown.css`, etc.) and docs titles; aliases may appear in descriptive copy only.

---

## Per‑component page schema (single source of truth)

Each page uses a JSON/TS config consumed by the vanilla renderer.

```ts
export type Key = "Enter"|"Space"|"Escape"|"ArrowUp"|"ArrowDown"|"ArrowLeft"|"ArrowRight";
export interface CSSContract {
  classNames: string[];                   // e.g., ['diet-badge', 'diet-badge--status']
  markup: string[];                       // ordered elements required in the DOM
  states: string[];                       // supported data attributes / pseudo selectors
  tokens: string[];                       // Dieter tokens this contract consumes
  aria: { role?: string; attributes?: string[]; keyboard?: Key[]; focus?: string };
  selectors: string[];                    // stable selectors for tests
  doNots: string[];                       // anti‑patterns to avoid
}
export interface ComponentDocSpec {
  title: string;
  status: "Core"|"Pattern"|"Planned";
  description: string;                    // Human overview
  anatomy: string[];                       // Element descriptions (slot-by-slot)
  css: string[];                           // References to the generated CSS files
  grid: {
    heading: string;                      // e.g., "Variants × Sizes"
    sizes: string[];                      // column headers
    variants: Array<{ name: string; description?: string; demoHtml: string }>; // HTML renders all sizes internally
  };
  states: Array<{ name: string; demoHtml: string; notes?: string }>; // strip of state tiles
  lightDarkDemo: { defaultHtml: string; darkHtml?: string };          // HTML snippets fed into iframe toggle
  examples: Array<{ title: string; html: string }>;  // Additional snippets rendered in collapsible sections
  ai: CSSContract;                         // Rules AIs must follow
}
```

Populate a `docs` map per component and feed into the renderer.

---

## Component backlog & acceptance criteria

### Wave 1 — Primitives (Core)

* **Badge, Box, Container, Divider, Link, Spinner**

  * DoD:

    * [ ] Component CSS lives alongside implementation when authored; use Dieter tokens exclusively (no hardcoded colors/sizes outside tokens).
    * [ ] Anatomy + states documented in `ComponentDocSpec`; demos include long text and RTL-safe layout (visual check only).
    * [ ] Unit tests (Vitest + jsdom) validate classlists, data attribute handling, and required accessibility hooks (e.g., focus outlines). Link demos must include `rel="noopener"` when `target="_blank"`.
    * [ ] Add entry to `src/data/routes.ts` and create `ComponentDocSpec` describing markup expectations + CSS contract.
    * [ ] Provide live HTML examples on the component page—variants × sizes grid first, states strip second, snippets below—and surface a tile on the Home gallery.

### Wave 2 — Forms (Core)

* **Input (TextField), Textarea, Checkbox, RadioGroup, Select (SelectList), Switch, Fieldset**

  * DoD:

    * [ ] Anatomy diagrams document required markup (`label`, input element, helper/error slots) and their class hooks.
    * [ ] CSS supports focus, error, disabled, and required states using tokens; no hardcoded pixel math.
    * [ ] Minimal vanilla JS demos illustrate keyboard behavior (RadioGroup roving tabindex, Select open/close on `Alt+ArrowDown`/`Escape`).
    * [ ] Tests validate ARIA relationships (`aria-describedby`, `aria-invalid`), keyboard traversal, and state class toggles.
    * [ ] Update docs data and gallery tiles; include examples for error + disabled states.

### Wave 3 — Overlays & Menus (Core)

* **Modal, OverlayPanel (Drawer), Popover, Tooltip, Tabs, Toast, Dropdown (Menu)**

  * DoD:

    * [ ] CSS contracts define overlay surfaces, scrims, and motion reduced behaviors via tokens only.
    * [ ] Vanilla JS demo utilities provide focus trap, Escape/outside-click dismissal, and tablist keyboard flows.
    * [ ] ARIA expectations documented (`role="dialog"`, `aria-modal`, labelled controls, `aria-live` for Toast) with selectors spelled out in `ComponentDocSpec`.
    * [ ] Tabs support manual activation via `Enter`/`Space`, optional auto activation toggled by data attribute.
    * [ ] Tests cover focus cycling, aria attributes, dismissal events, and reduced-motion fallbacks.
    * [ ] Provide interactive examples using Dieter tokens only; update CSS contract definitions accordingly.

### Wave 4 — Patterns (recipes)

* **ActivationCard, Banner (Callout/Slim/Upsell), HelpButton, PageHeader, Mask, Sticky**

  * DoD:

    * [ ] Compose patterns using previously defined CSS primitives—no new low-level tokens without approval.
    * [ ] Responsive behavior + semantic regions documented (e.g., banners as `role="status"`).
    * [ ] Examples include do/don’t callouts and AI contract data enumerating allowed sub-components/variants.
    * [ ] Document composition details (required wrappers, spacing utilities) so automation can rebuild the pattern.
    * [ ] Provide end-to-end demos/tests validating composition behaviors and sticky interactions.

### Wave 5 — Extras (full scope)

* **ButtonSocial, Datapoint, DateInput, Indicator (StatusDot), Pulsar**

  * DoD:

    * [ ] Minimal surfaces; follow tokens; respects `prefers-reduced-motion` (document fallback styles where motion is disabled).
    * [ ] DateInput: wrap native `type=date` with CSS only; demos show Dieter-aligned labeling, helper text, and error state parity.
    * [ ] Provide complete documentation (Human + AI contract), live examples, and interaction/unit tests covering critical behaviors for each CSS contract.

---

## Tokens (lab‑only)

* Mirror Dieter names: copy values from `documentation/systems/Dieter.md` (`--color-bg`, `--color-surface`, `--color-text`, `--color-border`, role tokens, `--space-*`, `--control-size-*`).
* Provide light + dark theme blocks plus `[data-theme]` override.
* Radii: expose `--radius-4` (0.5rem) by default; introduce lab helper `--radius` if needed, but keep actual values consistent with Dieter.
* Motion: respect `prefers-reduced-motion: reduce` for any transitions/animations.

---

## Utilities

* `.visually-hidden` (SR-only text).
* `.stack-*` spacing helpers using `gap` + `--space-*` tokens.
* `.grid-*` simple responsive grids keyed off breakpoints defined in `layout.css`.

---

## Accessibility checklist (apply per component)

* Document the semantic role and required ARIA attributes in the component spec.
* Provide keyboard interaction tables covering focus entry, traversal, activation, and escape.
* Ensure focus styling is visible (uses Dieter focus tokens) and remains on reduced-motion systems.
* For overlays/dialogs, trap focus while open, restore it on close, and support `Escape` dismissal unless explicitly prohibited.
* Validate name/description computation with jsdom + Testing Library (e.g., `getByRole`, `getByLabelText`).
* Include reduced-motion behavior notes for animated components (Spinner, Pulsar, overlays).

---

## Testing strategy

* **Unit:** Vitest + @testing-library/dom/jsdom helpers to assert markup, classes, and aria wiring.
* **A11y smoke:** integrate `axe-core` against generated HTML previews during dev; no framework adapters required.
* **Interaction tests:** For overlays (Modal/Popover/Menu/Tabs) verify keyboard and focus behavior using vanilla JS controllers.

---

## Build & run

```bash
cd lab/NewDieterLAB
pnpm i
pnpm dev      # opens local site with nav + gallery
pnpm build    # outputs to lab/NewDieterLAB/dist (kept inside lab)
pnpm test     # run Vitest suite
```

---

## Definition of Done (lab scope)

* [ ] `index.html` renders docs shell with left nav and tiled gallery; Dieter button/segmented previews match `admin/dietercomponents.html`.
* [ ] All **Wave 1–5** components implemented with docs pages (Human + AI contract) and supporting tests.
* [ ] Every new contract demo is visually/regression-checked against the existing Dieter preview; deviations marked `MISSING` with rationale in `DECISIONS.md`.
* [ ] No imports or writes outside `lab/NewDieterLAB/`.
* [ ] Short README in this folder describing how to run and what’s included.

---

## Execution notes for Codex

### Recommended sequence

1. **Environment** — complete Setup steps 1–9.
2. **Dieter parity** — port Button/Segmented/Color/Typography previews; ensure styling matches `admin/dietercomponents.html` exactly.
3. **Docs shell** — implement layout, navigation, home gallery, and component page template using the parity previews as initial content.
4. **Wave 1 primitives** — implement CSS contracts + docs/tests.
5. **Wave 2 forms** — implement CSS contracts + docs/tests.
6. **Wave 3 overlays** — implement CSS contracts + docs/tests.
7. **Wave 4 patterns** — implement CSS contracts + docs/tests.
8. **Wave 5 extras** — implement CSS contracts + docs/tests.
9. **Regression pass** — run `pnpm test`, manual a11y checks, compare Dieter previews against lab components.

### General guidance

* Work in waves; complete DoD per wave before moving on.
* Keep PRs small and self-contained **inside** `lab/NewDieterLAB/`.
* Favor "boring" commands: avoid watchers/servers unless explicitly testing; prefer one-shot invocations that exit cleanly.
* Maintain a "safe + boring" execution posture for the entire lab: no speculative commands, no destructive flags, and avoid actions likely to trigger sandbox blocking or escalation. Do not initiate actions that require user approvals or pause execution.
* You may import/read from `dieter/dist/**` or other Dieter sources for reference, but never edit those files.
* If a requirement conflicts with guardrails, **stop and document** in a `DECISIONS.md` inside this folder and request review.

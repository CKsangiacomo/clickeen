# New Dieter Lab

This lab replicates and extends the Dieter component previews inside an isolated Vite + TypeScript workspace.

## Getting started

```bash
pnpm install
pnpm dev     # start the docs shell locally
pnpm test    # run Vitest suite
pnpm build   # build production bundle
```

## Guardrails

- All work stays inside `lab/NewDieterLAB/`.
- Dieter assets under `dieter/` are read-only references.
- Commands should be one-shot and non-interactive unless explicitly running dev/test servers.
- Follow `documentation/systems/Dieter.md` for tokens, spacing, and behavior prior to coding.
- Document assumptions in `DECISIONS.md` if conflicts arise.

## Reference

The Dieter demos remain available at `admin/dietercomponents.html` for parity checks.

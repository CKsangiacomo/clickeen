# Lab Components Execution Plan — September 25\


**** CRITICAL ****
**** COMPLETE SCRIPT END TO END INDIPENDENTLY WITHOUT ASKING HUMAN INTERVENTION  *****
**** RUN ALL STEPS FOR EACH COMPONENT ****
**** DO NOT MOVE TO NEXT COMPONENT BEFORE GATES ARE GREEN ****
**** DO NOT EXIT TASK UNTIL ALL COMPONENTS ARE DONE ****

**Scope:** Implement the "Lab" component backlog inside `lab/NewDieterLAB/`, leveraging Gestalt’s documentation UI patterns while authoring Dieter-compliant CSS contracts and demos. Dieter showcase previews (`src/html/dieter/**`) remain frozen unless parity bugs surface.

---

## 0. Reference Stack
- **Docs shell:** `src/main.ts`, `src/router.ts`, `src/css/layout.css`, `src/css/utilities.css`
- **Gestalt inspiration:** `TMP_OLDREPO/gestalt/docs` (local clone: `/Users/piero_macpro/code/clickeen/TMP_OLDREPO/gestalt/`) for layout, section structure, and copy cadence
- **Tokens & rules:** `documentation/systems/Dieter.md`, `documentation/CRITICAL-TECHPHASES/Techphases-Phase1Specs.md`
- **Existing admin markup:** use `admin/dietercomponents.html` and Gestalt demos as fidelity references
- **Workflow discipline:** commands must stay one-shot (run dev servers only when verifying locally; no blocking watchers during implementation).

- **Step 1:** Open the Gestalt reference page and reread Dieter + Phase‑1 specs for the component.
- **Step 1a:** Open button and segmented control (dieter components) For applicable , repeatable patterns
- **Step 2:** Author the CSS contract in `src/css/components/<area>/` using Dieter tokens only.
- **Step 2a:** compare your generated CSS for Dieter sizes 8/16/24/32 etc. If they're applicable, are they respected.  
- **Step 3:** Create HTML demos in `src/html/components/` for variants, states, and snippets.
- **Step 4:** Update `src/data/routes.ts` with anatomy, grid, states, examples, and AI contract info.
- **Step 5:** Add Vitest DOM tests in `src/tests/` covering classes, states, and accessibility hooks.
- **Step 6:** Load `#/components/<id>` in the lab, verify visuals/accessibility/responsiveness, and only then mark the component complete.
- **Step 7:** Run these checks indipendently before moving to next components: 1) have I used system colors in the most elegant manner, 2) will this component work side by side similar components, 3) is this the most modern and elegant solution (think Apple/Stripe polish).
- **Gate:** Do not start the next component until every step above passes (tests green, visual review approved, checklist signed off).

---

## 1. Component Backlog (Lab)
Work strictly one component at a time. Finish the current component (CSS, HTML demos, docs data, tests) before selecting the next from the backlog. Tailor the order based on product need, not wave batching.

**Remaining components:**

**Group1:**
- [ ] Badge
- [ ] Box
- [ ] Container
- [ ] Divider
- [ ] Link
- [ ] Spinner
- [ ] Input
- [ ] Textarea
**Group2:**
- [x] Checkbox ✅ COMPLETE
- [x] Radio Group ✅ COMPLETE
- [x] Select ✅ COMPLETE
- [x] Switch ✅ COMPLETE
- [x] Fieldset ✅ COMPLETE
- [x] Modal ✅ COMPLETE
- [x] Overlay Panel ✅ COMPLETE
- [x] Popover ✅ COMPLETE
- [x] Tooltip ✅ COMPLETE
**Group3:**
- [ ] Tabs
- [ ] Toast
- [ ] Dropdown
- [ ] Activation Card
- [ ] Banner
- [ ] Help Button
- [ ] Page Header
**Group4:**
- [ ] Mask
- [ ] Sticky
- [ ] Button Social
- [ ] Datapoint
- [ ] Date Input
- [ ] Indicator
- [ ] Pulsar

---

## 2. Definition of Done (per component)
1. **CSS contract**: new stylesheet under `src/css/components/<area>/<component>.css` using Dieter tokens only (no hard-coded colors, spacing, or font sizes outside token values).
2. **HTML demos**: fragments in `src/html/components/` covering:
   - Variants × sizes grid (mirrors Gestalt docs: heading, metadata block, multiple instances)
   - State strip (disabled, focus, error, etc. as applicable)
   - Additional snippets/examples (usage patterns, composition)
3. **Docs data**: update `src/data/routes.ts` entry with:
   - Accurate `anatomy` array
   - `grid` metadata referencing new demo fragment paths
   - `states` list and notes
   - `examples` array for snippets
   - `ai` contract (class names, data attributes, selectors, tokens, do/ do-nots)
4. **Accessibility notes**: cite expected roles/ARIA in `ai.aria` and ensure markup includes `aria-*`, `role`, `tabindex` per Dieter spec.
5. **Testing**: add Vitest DOM tests (`src/tests/<component>.test.ts`) verifying class hooks, states, and accessibility flags (e.g., `getByRole`, `getByLabelText`).
6. **Docs rendering**: load the component page (`#/components/<id>`) and confirm layout parity (Gestalt-inspired headings, spacing, grids, states, snippet accordions) with Dieter styling.

---

## 3. Work Sequence (repeat per component)
1. **Research**
   - Review Gestalt component page for layout/section cues.
   - Re-read relevant section in `documentation/systems/Dieter.md` or `Techphases-Phase1Specs.md` to capture tokens/behaviour requirements.
2. **CSS authoring**
   - Scaffold new stylesheet (create directory if missing).
   - Define root class, modifiers, data attributes; include light/dark considerations and all interaction states (hover, active, selected, focus) using Dieter tokens.
3. **Markup authoring**
   - Translate Gestalt examples into Dieter markup; embed inline SVGs/icons when needed from Dieter assets (`@dieter/icons/svg/*`).
   - Use existing utility classes (`stack`, `grid`) for layout where helpful.
   - Decide variants/sizes based on the Dieter spec: include only the variants the contract requires. If Dieter defines size modifiers (`data-size`, etc.), demo each size; otherwise document that sizes are not applicable.
4. **Docs wiring**
   - Update `routes.ts` entry with correct spec metadata.
   - Place fragments under `src/html/components/<component>-*.html` and reference them from the spec.
5. **Testing**
   - Add unit tests ensuring markup renders, attribute toggles behave, and required accessibility guidance is present.
6. **Manual verification**
   - Run `pnpm --filter newdieterlab dev`, navigate to the component page, compare with Gestalt and Dieter expectations.
7. **Document findings**
   - If Dieter tokens lack required values or behaviour is undefined, mark `MISSING` in `routes.ts` and log in `DECISIONS.md`.

---

## 4. Styling & Layout Guidance
- Follow Gestalt’s typography hierarchy: section headings (`heading-4`), metadata labels (`caption`), cell labels (`body`/`caption`).
- Use `.dieter-preview__*` helpers where parity with the showcase is useful; otherwise, create component-specific wrappers under `components/<area>/<component>.css`.
- Provide spacing with `var(--space-*)` tokens and radii via `var(--radius-4)` or component-specific tokens.
- For interactions (hover, active, focus), rely on Dieter state tokens (`--state-hover-alpha-on-surface`, etc.)—no raw rgba values.

---

## 5. Documentation Layout Expectations
- Intro copy summarising component purpose (1–2 sentences).
- **Variants × Sizes** section: table-like grid listing metadata (variants, tokens) and actual component instance.
- **States** section: row of tiles showing disabled/hover/selected/error states.
- **Snippets**: collapsible `<details>` blocks with labelled examples (Gestalt-style “Usage”, “Do”, “Don’t” as needed).
- **Tokens**: list tokens consumed (`spec.ai.tokens`).
- **Accessibility**: bullets describing roles, required labels, keyboard support.

---

## 6. Testing Expectations
- Unit tests per component verifying:
  - Rendered fragments contain expected classes and data attributes.
  - Accessibility hooks present (`aria-label`, `aria-expanded`, `role` values).
  - Interaction toggles (e.g., `data-selected`, `disabled`) adjust classes.
- Snapshot testing optional but encouraged once markup stabilises.
- Manual QA: cross-check against screenshots/Gestalt; ensure responsive behaviour (grid wraps, layout still legible at 320px width).

---

## 7. Acceptance Criteria (Component complete when…)
- All components in the wave satisfy Definition of Done and pass tests.
- `pnpm --filter newdieterlab build` succeeds without warnings.
- `#/components/<component>` pages show Dieter-styled examples with Gestalt-like documentation structure.
- No TODO placeholders remain for that wave.
- `DECISIONS.md` documents any outstanding Dieter spec gaps.

---

## 8. Reporting
- Track progress per component in this doc (append checklists/results).
- Summarise completed components and outstanding blockers in commit notes or stand-ups.

---

*Prepared Sept 25 by Codex AI for the Lab-only component build-out.*
